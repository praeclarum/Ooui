﻿using Ooui;
using Xamarin.Forms;

namespace $safeprojectname$
{
	class Program
    {
        static void Main(string[] args)
        {
			Forms.Init ();

			UI.Publish ("/", new MainPage ().GetOouiElement ());
		}
    }
}